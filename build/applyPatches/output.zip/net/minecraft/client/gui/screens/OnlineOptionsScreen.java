package net.minecraft.client.gui.screens;

import net.minecraft.client.Option;
import net.minecraft.client.Options;
import net.minecraft.client.gui.components.CycleButton;
import net.minecraft.network.chat.TranslatableComponent;
import net.minecraft.world.Difficulty;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class OnlineOptionsScreen extends SimpleOptionsSubScreen {
   private static final Option[] f_193840_ = new Option[]{Option.f_91642_, Option.f_193592_};

   public OnlineOptionsScreen(Screen p_193843_, Options p_193844_) {
      super(p_193843_, p_193844_, new TranslatableComponent("options.online.title"), f_193840_);
   }

   protected void m_7853_() {
      if (this.f_96541_.f_91073_ != null) {
         CycleButton<Difficulty> cyclebutton = this.m_142416_(OptionsScreen.m_193846_(f_193840_.length, this.f_96543_, this.f_96544_, "options.difficulty.online", this.f_96541_));
         cyclebutton.f_93623_ = false;
      }

      super.m_7853_();
   }
}