package net.minecraft.world.entity.npc;

public interface VillagerDataHolder {
   VillagerData m_7141_();

   void m_141967_(VillagerData p_150027_);
}