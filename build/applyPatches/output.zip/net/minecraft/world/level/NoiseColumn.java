package net.minecraft.world.level;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.BlockColumn;

public final class NoiseColumn implements BlockColumn {
   private final int f_151621_;
   private final BlockState[] f_47149_;

   public NoiseColumn(int p_151623_, BlockState[] p_151624_) {
      this.f_151621_ = p_151623_;
      this.f_47149_ = p_151624_;
   }

   public BlockState m_183556_(int p_186552_) {
      int i = p_186552_ - this.f_151621_;
      return i >= 0 && i < this.f_47149_.length ? this.f_47149_[i] : Blocks.f_50016_.m_49966_();
   }

   public void m_183639_(int p_186554_, BlockState p_186555_) {
      int i = p_186554_ - this.f_151621_;
      if (i >= 0 && i < this.f_47149_.length) {
         this.f_47149_[i] = p_186555_;
      } else {
         throw new IllegalArgumentException("Outside of column height: " + p_186554_);
      }
   }
}