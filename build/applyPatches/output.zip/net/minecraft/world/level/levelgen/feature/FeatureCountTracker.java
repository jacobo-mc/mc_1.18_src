package net.minecraft.world.level.levelgen.feature;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.Object2IntMaps;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import java.util.Optional;
import java.util.concurrent.TimeUnit;
import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.levelgen.placement.PlacedFeature;
import org.apache.commons.lang3.mutable.MutableInt;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class FeatureCountTracker {
   private static final Logger f_190876_ = LogManager.getLogger();
   private static final LoadingCache<ServerLevel, FeatureCountTracker.LevelData> f_190877_ = CacheBuilder.newBuilder().weakKeys().expireAfterAccess(5L, TimeUnit.MINUTES).build(new CacheLoader<ServerLevel, FeatureCountTracker.LevelData>() {
      public FeatureCountTracker.LevelData load(ServerLevel p_190902_) {
         return new FeatureCountTracker.LevelData(Object2IntMaps.synchronize(new Object2IntOpenHashMap<>()), new MutableInt(0));
      }
   });

   public static void m_190881_(ServerLevel p_190882_) {
      try {
         f_190877_.get(p_190882_).f_190917_().increment();
      } catch (Exception exception) {
         f_190876_.error(exception);
      }

   }

   public static void m_190883_(ServerLevel p_190884_, ConfiguredFeature<?, ?> p_190885_, Optional<PlacedFeature> p_190886_) {
      try {
         f_190877_.get(p_190884_).f_190916_().computeInt(new FeatureCountTracker.FeatureData(p_190885_, p_190886_), (p_190891_, p_190892_) -> {
            return p_190892_ == null ? 1 : p_190892_ + 1;
         });
      } catch (Exception exception) {
         f_190876_.error(exception);
      }

   }

   public static void m_190880_() {
      f_190877_.invalidateAll();
      f_190876_.debug("Cleared feature counts");
   }

   public static void m_190899_() {
      f_190876_.debug("Logging feature counts:");
      f_190877_.asMap().forEach((p_190888_, p_190889_) -> {
         String s = p_190888_.m_46472_().m_135782_().toString();
         boolean flag = p_190888_.m_142572_().m_130010_();
         Registry<PlacedFeature> registry = p_190888_.m_5962_().m_175515_(Registry.f_194567_);
         String s1 = (flag ? "running" : "dead") + " " + s;
         Integer integer = p_190889_.f_190917_().getValue();
         f_190876_.debug(s1 + " total_chunks: " + integer);
         p_190889_.f_190916_().forEach((p_190897_, p_190898_) -> {
            f_190876_.debug(s1 + " " + String.format("%10d ", p_190898_) + String.format("%10f ", (double)p_190898_.intValue() / (double)integer.intValue()) + p_190897_.f_190906_().flatMap(registry::m_7854_).map(ResourceKey::m_135782_) + " " + p_190897_.f_190905_().m_65394_() + " " + p_190897_.f_190905_());
         });
      });
   }

   static record FeatureData(ConfiguredFeature<?, ?> f_190905_, Optional<PlacedFeature> f_190906_) {
   }

   static record LevelData(Object2IntMap<FeatureCountTracker.FeatureData> f_190916_, MutableInt f_190917_) {
   }
}