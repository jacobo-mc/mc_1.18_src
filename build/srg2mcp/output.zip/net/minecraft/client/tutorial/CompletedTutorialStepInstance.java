package net.minecraft.client.tutorial;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class CompletedTutorialStepInstance implements TutorialStepInstance {
   public CompletedTutorialStepInstance(Tutorial p_120459_) {
   }
}