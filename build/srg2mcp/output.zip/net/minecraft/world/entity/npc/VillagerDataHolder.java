package net.minecraft.world.entity.npc;

public interface VillagerDataHolder {
   VillagerData getVillagerData();

   void setVillagerData(VillagerData p_150027_);
}